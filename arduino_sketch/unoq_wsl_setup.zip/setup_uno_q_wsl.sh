#!/usr/bin/env bash
set -euo pipefail

# Config
SKETCH_NAME="Teleo_RTU_Replica_LED_Heartbeat_Debug_Timestamp.ino"
SKETCH_DIR="$HOME/Arduino/TeleoApp"
LIB_DIR="$HOME/Arduino/libraries"
BOARD_FQBN="arduino:renesas_uno"
SERIAL_PORT="${SERIAL_PORT:-/dev/ttyACM0}"  # override with SERIAL_PORT if needed

# 0) Check Arduino CLI
if ! command -v arduino-cli >/dev/null 2>&1; then
  echo "ERROR: arduino-cli not found in PATH. Install it first (see README)."
  exit 1
fi

# 1) Check sketch file is present
if [[ ! -f "$SKETCH_NAME" ]]; then
  echo "ERROR: $SKETCH_NAME not found in current directory."
  echo "Place the .ino next to this script or export SKETCH_NAME=<path> and rerun."
  exit 1
fi

# 2) Create dirs, copy sketch
mkdir -p "$SKETCH_DIR" "$LIB_DIR"
cp -f "$SKETCH_NAME" "$SKETCH_DIR/"

# 3) Install ModbusMaster fork (ant32t)
TMP_ZIP="/tmp/ModbusMaster.zip"
echo "Downloading ModbusMaster fork..."
curl -L -o "$TMP_ZIP" "https://github.com/ant32t/ModbusMaster/archive/refs/heads/master.zip"
unzip -o "$TMP_ZIP" -d "$LIB_DIR"
rm -f "$TMP_ZIP"
if [[ -d "$LIB_DIR/ModbusMaster-master" ]]; then
  rm -rf "$LIB_DIR/ModbusMaster"
  mv "$LIB_DIR/ModbusMaster-master" "$LIB_DIR/ModbusMaster"
fi

# 4) Confirm device path
if [[ ! -e "$SERIAL_PORT" ]]; then
  echo "WARNING: $SERIAL_PORT not found. Available tty devices:"
  ls -l /dev/ttyACM* /dev/ttyUSB* 2>/dev/null || true
  echo "Set SERIAL_PORT=/dev/ttyACM<N> and rerun, e.g.:"
  echo "SERIAL_PORT=/dev/ttyACM1 ./setup_uno_q_wsl.sh"
  exit 1
fi

# 5) Compile
echo "Compiling sketch..."
arduino-cli compile --fqbn "$BOARD_FQBN" "$SKETCH_DIR"

# 6) Upload
echo "Uploading to $SERIAL_PORT ..."
arduino-cli upload -p "$SERIAL_PORT" --fqbn "$BOARD_FQBN" "$SKETCH_DIR"

echo "Done! The sketch is now running on your Uno Q."
echo "Open a serial monitor at 115200 baud to see timestamped logs."
