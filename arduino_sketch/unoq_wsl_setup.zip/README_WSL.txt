WSL Setup Package for Arduino Uno Q
===================================

Files:
- setup_uno_q_wsl.sh : One-shot setup script (run inside WSL)
- Teleo_RTU_Replica_LED_Heartbeat_Debug_Timestamp.ino : Sketch with LED heartbeat and timestamped logs

Prereqs (Windows side):
1) Install usbipd-win and ensure WSL 2 is up to date.
2) Plug in Uno Q via USB and run in Windows PowerShell:
   - usbipd list
   - usbipd attach --wsl --busid <BUSID>

Linux side (WSL):
1) Install Arduino CLI in WSL:
   - sudo apt update && sudo apt install -y curl unzip tar
   - mkdir -p ~/bin
   - curl -fsSL https://downloads.arduino.cc/arduino-cli/arduino-cli_latest_Linux_64bit.tar.gz | tar -xz -C ~/bin
   - echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc && source ~/.bashrc
   - arduino-cli core update-index && arduino-cli core install arduino:renesas_uno

2) Run the setup script:
   - chmod +x setup_uno_q_wsl.sh
   - ./setup_uno_q_wsl.sh
   (If your device shows as /dev/ttyACM1, run: SERIAL_PORT=/dev/ttyACM1 ./setup_uno_q_wsl.sh)

After upload:
- LED matrix cycles: OK/ERR, S:# E:#, R:#, RUN
- Serial monitor (WSL): arduino-cli monitor -p /dev/ttyACM0 -c baudrate=115200
